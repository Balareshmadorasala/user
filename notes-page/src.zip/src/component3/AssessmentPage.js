import React, { useState } from "react";
import { Container, Form, Button, Row, Col } from "react-bootstrap";
import "./AssessmentPage.css";

const AssessmentPage = () => {
  const [questions, setQuestions] = useState([]); // Array to store all questions
  const [newQuestions, setNewQuestions] = useState([]); // Array to hold questions before saving
  const [newQuestion, setNewQuestion] = useState({
    type: "Essay",
    text: "",
    options: ["", "", "", ""], // Default options for Choice questions
    correctAnswer: "",
  });

  // Function to save all questions to the main array
  const saveQuestions = () => {
    if (newQuestions.length === 0) {
      alert("No questions to save!");
      return;
    }

    setQuestions((prevQuestions) => [...prevQuestions, ...newQuestions]); // Save new questions to the main array
    setNewQuestions([]); // Clear temporary array
  };

  // Function to add a new question to the temporary array
  const addQuestion = () => {
    if (!newQuestion.text.trim() || !newQuestion.correctAnswer.trim()) {
      alert("Please provide question text and correct answer.");
      return;
    }

    setNewQuestions((prevQuestions) => [...prevQuestions, newQuestion]); // Add new question to temporary array
    setNewQuestion({ type: "Essay", text: "", options: ["", "", "", ""], correctAnswer: "" }); // Reset form
  };

  // Function to add an empty option for Choice questions
  const addOption = () => {
    setNewQuestion((prevQuestion) => ({
      ...prevQuestion,
      options: [...prevQuestion.options, ""], // Add an empty option
    }));
  };

  return (
    <Container className="mt-5 assessment-container">
      <h2>Assessment Creation</h2>

      <div className="assessment-section d-flex">
        <div className="left-section me-5" style={{ flex: 2 }}>
          <h4>Create Questions</h4>

          <Form>
            <Row className="mb-3">
              <Col xs={8}>
                <Form.Control
                  type="text"
                  placeholder="Enter question"
                  value={newQuestion.text}
                  onChange={(e) => setNewQuestion({ ...newQuestion, text: e.target.value })}
                />
              </Col>
              <Col xs={4} className="text-end">
                <Form.Select
                  value={newQuestion.type}
                  onChange={(e) => setNewQuestion({ ...newQuestion, type: e.target.value })}
                >
                  <option value="Essay">Essay Question</option>
                  <option value="Choice">Choice Question</option>
                </Form.Select>
              </Col>
            </Row>

            {newQuestion.type === "Choice" && (
              <>
                {newQuestion.options.map((option, index) => (
                  <Row key={index} className="mb-2">
                    <Col xs={8}>
                      <Form.Control
                        type="text"
                        placeholder={`Option ${index + 1}`}
                        value={newQuestion.options[index]}
                        onChange={(e) => {
                          const updatedOptions = [...newQuestion.options];
                          updatedOptions[index] = e.target.value;
                          setNewQuestion({ ...newQuestion, options: updatedOptions });
                        }}
                      />
                    </Col>
                    <Col xs={4} className="text-end">
                      <Form.Check
                        type="radio"
                        name="correctAnswer"
                        label="Correct"
                        onChange={() => setNewQuestion({ ...newQuestion, correctAnswer: option })}
                      />
                    </Col>
                  </Row>
                ))}
                <Button variant="secondary" onClick={addOption}>
                  Add Option
                </Button>
              </>
            )}

            {newQuestion.type === "Essay" && (
              <Row className="mb-2">
                <Col>
                  <Form.Control
                    type="text"
                    placeholder="Enter correct answer"
                    value={newQuestion.correctAnswer}
                    onChange={(e) => setNewQuestion({ ...newQuestion, correctAnswer: e.target.value })}
                  />
                </Col>
              </Row>
            )}

            <Button className="mt-3" onClick={addQuestion}>
              Add Question
            </Button>
          </Form>

          {/* Display Temporary Questions */}
          <div className="temp-questions mt-4">
            <h5>New Questions:</h5>
            {newQuestions.length === 0 ? (
              <p>No new questions added yet.</p>
            ) : (
              <ul>
                {newQuestions.map((q, index) => (
                  <li key={index}>
                    <strong>{q.type}:</strong> {q.text}
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Save Questions */}
          <Button variant="success" className="mt-4" onClick={saveQuestions}>
            Save All Questions
          </Button>
        </div>

        <div className="right-section" style={{ flex: 1 }}>
          <h5>Assessment Options</h5>
          <Form>
            <Form.Group className="mb-2">
              <Form.Label>Question Type</Form.Label>
              <Form.Select>
                <option>Add Questions Online</option>
              </Form.Select>
            </Form.Group>

            <Form.Group className="mb-2">
              <Form.Label>Submission Type</Form.Label>
              <Form.Select>
                <option>Online</option>
              </Form.Select>
            </Form.Group>

            <Form.Group className="mb-2">
              <Form.Label>Due Date</Form.Label>
              <Form.Control type="date" />
            </Form.Group>

            <Form.Group className="mb-2">
              <Form.Label>Course Weight</Form.Label>
              <Form.Control type="number" placeholder="e.g., 6.2" />
            </Form.Group>

            <Form.Group className="mb-2">
              <Form.Label>Max Score</Form.Label>
              <Form.Control type="number" placeholder="0" />
            </Form.Group>

            <Button variant="success" className="mt-2">
              Create
            </Button>
          </Form>
        </div>
      </div>

      {/* Display Stored Questions */}
      <div className="stored-questions mt-5">
        <h5>Stored Questions:</h5>
        {questions.length === 0 ? (
          <p>No questions saved yet.</p>
        ) : (
          <ul>
            {questions.map((q, index) => (
              <li key={index}>
                <strong>{q.type}:</strong> {q.text}
              </li>
            ))}
          </ul>
        )}
      </div>
    </Container>
  );
};

export default AssessmentPage;











