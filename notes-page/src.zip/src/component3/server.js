const express = require("express");
const cors = require("cors");
const app = express();

// Enable CORS for all routes
app.use(cors());

// Your routes (e.g., for questions)
app.get("/api/questions", (req, res) => {
  res.json({ message: "This is the questions endpoint" });
});

// Start the server
app.listen(5000, () => {
  console.log("Backend server running on http://localhost:5000");
});

