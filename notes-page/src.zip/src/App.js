import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import AssessmentPage from "./component3/AssessmentPage";


const App = () => {
  return (
    <Router>  {/* Ensure Router wraps everything */}
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/assessment" element={<AssessmentPage />} />
      </Routes>
    </Router>
  );
};

const HomePage = () => {
  return (
    <div className="container mt-5">
      <h2>Welcome to the Assessment Portal</h2>
      <p>Click below to create and manage assessments.</p>
      <a href="/assessment" className="btn btn-primary">Go to Assessments</a>
    </div>
  );
};




export default App;









